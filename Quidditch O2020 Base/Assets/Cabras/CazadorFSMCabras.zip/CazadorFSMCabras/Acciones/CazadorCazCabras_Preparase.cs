﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CazadorCazCabras_Prepararse : FSMStatesCazCabras
{
    private elCazadorCabras Cazador;

    public CazadorCazCabras_Prepararse(FSMCazCabras fsm, Animator animator, elCazadorCabras Cazador) : base(fsm, animator)
    {
        this.Cazador = Cazador; 
    }



    public override void Enter()
    {

        base.Enter();
        Cazador.steering.Target = Cazador.myStartingPosition;
        Cazador.steering.arrive = true;
        Cazador.steering.arriveWeight = 1f;
        //Buscamos la Quaffle
    }


    public override void UpdateEstado()
    {
        Debug.Log("Aquí ando");
        //Si la Quaffle ya no tiene dueño
        if (Cazador.myStartingPosition != null && !GameManager.instancia.isGameStarted())
        {
            if (Vector3.Distance(Cazador.transform.position, Cazador.steering.Target.position) < 3f)
            {
                FSM.CambiarDeEstado(Cazador.EstadoEsperar);
            }
        }
        if (GameManager.instancia.isGameStarted())
        {
            FSM.CambiarDeEstado(Cazador.PerseguirPelota);
        }



    }

    public override void Exit()
    {

    }
}