﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class elCazadorCabras : Player
{
    public FSMCazCabras fsmCabras;

    //Lista de edos
    public FSMStatesCazCabras PerseguirPelota;
    public FSMStatesCazCabras BuscarAro;
    public FSMStatesCazCabras Acompaniar;
    public FSMStatesCazCabras EstadoEsperar;
    public FSMStatesCazCabras SeguirARival;
    public FSMStatesCazCabras PrepararseInicioJuego;


    public Animator animator;
    public float ThrowStrength = 50;
    public float DistanceToShoot = 500;

    public Transform posicionUno;
    public Transform posicionDos;

    public int numeroParaSeguir;


    // Start is called before the first frame update
    protected override void Start()
    {
        base.Start();

        //Agregar edos. del agente
        //Buscar pelota, buscar portería (acción: lanzar la pelota)
        fsmCabras = new FSMCazCabras(this);

        PrepararseInicioJuego = new CazadorCazCabras_Prepararse(fsmCabras, animator, this);
        PerseguirPelota = new CazadorCazCabras_PerseguirBola(fsmCabras, animator, this);
        BuscarAro = new CazadorCazCabras_BuscarAro(fsmCabras, animator, this);
        Acompaniar = new CazadirCazCabras_Acompaniar(fsmCabras, animator, this);
        EstadoEsperar = new CazadorCazCabras_Esperar(fsmCabras, animator, this);
        SeguirARival = new CazadorCazCabras_RivalChase(fsmCabras, animator, this);

        //Cual es su edo. inicial
        fsmCabras.Iniciar(PrepararseInicioJuego);

    }

    // Update is called once per frame
    protected override void Update()
    {
        base.Update();
        fsmCabras.Update();
    }
}
